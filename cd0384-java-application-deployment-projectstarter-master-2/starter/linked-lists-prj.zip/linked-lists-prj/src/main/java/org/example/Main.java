package org.example;

import java.util.Arrays;

public class Main {

    public static int minFinder(int[] arr) {
        //iterative
        int minValue = arr[0];
        for(int c = 1;c < arr.length; c++){
            if(arr[c] < minValue){
                minValue = arr[c];
            }
        }
        return minValue;
    }

    public static int minFinderRecursive(int[] arr, int length) {
        //iterative
        if(length == 1)
            return arr[0];
        return Math.min(arr[length - 1], minFinderRecursive(arr, length - 1));
    }

    public static void main(String[] args) {
        int Arr[] = {-9,8,6,3,1,34,11};
        int len = Arr.length;

        System.out.println("Array Arr contents: ");
        Arrays.stream(Arr).forEach(System.out::println);
        System.out.println("Min value recursive: " + minFinderRecursive(Arr, Arr.length));
        System.out.println("Min value iterative: " + minFinder(Arr));


        LinkedList c1= new LinkedList();
        c1.add(1);
        c1.add(2);
        c1.add(3);

        LinkedList c2= new LinkedList();
        c2.add(1);
        c2.add(2);
        c2.add(3);

        //comparison output in linked list
        System.out.println("c1: " + c1.toString());
        System.out.println("c2: " + c2.toString());
        System.out.println("c1 == c2: " + c1.compare(c2));

        System.out.println("Modify c2");
        c2.add(4);
        System.out.println("c1: " + c1.toString());
        System.out.println("c2: " + c2.toString());
        System.out.println("c1 == c2: " + c1.compare(c2));

        System.out.println("Delete 2 from c2: ");
        c2.remove(2);
        System.out.println("c2 is now; " + c2.toString());

        System.out.println("Check c1 contains 3: " + c1.contains(3));

        System.out.println("Size of c1: " + c1.size());

    }
}