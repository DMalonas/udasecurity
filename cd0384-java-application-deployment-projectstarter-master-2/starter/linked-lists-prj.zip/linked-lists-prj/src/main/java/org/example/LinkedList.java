package org.example;


class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
    }
}
public class LinkedList {
    private Node root;

    public void add(int data) {
        Node newRoot = new Node(data);
        newRoot.next = root;
        root = newRoot;
    }

    void remove(int value) {
        Node temp = root, prev = null;
        if (temp != null && temp.data == value) {
            root = temp.next;
            return;
        }
        while (temp != null && temp.data != value) {
            prev = temp;
            temp = temp.next;
        }
        if (temp == null)
            return;
        prev.next = temp.next;
    }

    public int size() {
        if (root == null) {
            System.out.println("List is Empty !!");
            return 0;
        }
        int size = 0;
        Node tmp = root;
        System.out.println();
        while (tmp != null) {
            tmp = tmp.next;
            size++;
        }
        return size;
    }


    public boolean contains(int value) {
        if (root == null) {
            System.out.println("List is Empty !!");
            return false;
        }
        int size = 0;
        Node tmp = root;
        System.out.println();
        while (tmp != null) {
            if (tmp.data == value) {
                return true;
            }
            tmp = tmp.next;
            size++;
        }
        return false;
    }

    public String toString() {
        if (root == null) {
            System.out.println("List is Empty !!");
            return "";
        }
        Node tmp = root;
        System.out.println();
        int cnt = size();
        String toString = "";
        while (tmp != null) {
            toString += "\nNode " + cnt + " = " + tmp.data ;
            tmp = tmp.next;
            cnt--;
        }
        return toString;
    }

    public boolean compare(LinkedList li) {
        Node tmp = root;
        Node tmp2 = li.root;
        System.out.println();
        String toString = "";
        while (tmp != null) {
            int tmpData = tmp.data;
            int tmp2Data = tmp2.data;
            if (tmpData != tmp2Data) {
                return false;
            }
            tmp = tmp.next;
            tmp2 = tmp2.next;
        }
        return true;
    }
}